# This is a R script for the Paper: Tresch et al. 2019: Litter decomposition driven by soil fauna, plant diversity and soil management in urban gardens


# The main purpose of this script is to understand the statistical computations made for this paper
# All codes are coded by the main author Simon Tresch based on literature given in the main paper and appendix.
# In case of any questions please contact the main author: simon.tresch@fibl.org

# Literature used for calculation of the indices and models
# Fontana, S., Petchey, O.L., Pomati, F., 2016. Individual-level trait diversity concepts and indices to comprehensively describe community change in multidimensional trait space. Funct. Ecol. 30, 808–818. doi:10.1111/1365-2435.12551
# Helmus, M.R., Bland, T.J., Williams, C.K., Ives, A.R., 2007. Phylogenetic Measures of Biodiversity. Am. Nat. 169, E68–E83. doi:10.1086/511334
# Kembel, S.W., Cowan, P.D., Helmus, M.R., Cornwell, W.K., Morlon, H., Ackerly, D.D., Blomberg, S.P., Webb, C.O., 2010. Picante: R tools for integrating phylogenies and ecology. Bioinformatics 26, 1463–1464. doi:10.1093/bioinformatics/btq166
# Korner-Nievergelt, F., Roth, T., Von Felten, S., Guélat, J., Almasi, B., Korner-Nievergelt, P., 2015. Bayesian data analysis in ecology using linear models with R, BUGS, and Stan. Academic Press.
# Laliberté, E., Legendre, P., 2010. A distance-based framework for measuring functional diversity from multiple traits. Ecology 91, 299–305. doi:10.1890/08-2244.1
# Michonneau, F., Brown, J.W., Winter, D.J., 2016. rotl : an R package to interact with the Open Tree of Life data. Methods Ecol. Evol. 7, 1476–1481. doi:10.1111/2041-210X.12593
# Paradis, E., 2011. Analysis of Phylogenetics and Evolution with R. Springer New York, New York, NY. doi:10.1007/978-1-4614-1743-9
# Paradis, E., Claude, J., Strimmer, K., 2004. APE: Analyses of Phylogenetics and Evolution in R language. Bioinformatics 20, 289–290. doi:10.1093/bioinformatics/btg412
# Villéger, S., Mason, N.W.H., Mouillot, D., 2008. New multidimensional functional diversity indices for a multifaceted framework in functional ecology. Ecology 89, 2290–2301. doi:10.1890/07-1206.1

# for a complet description of the data including more data about the sampled urban garden sites please consider: 
  # Tresch, S., Moretti, M., Le Bayon, R.-C., Mäder, P., Zanetta, A., Frey, D., Stehle, B., Kuhn, A., Munyangabe, A., Fliessbach, A., 2018b. Urban Soil Quality Assessment—A Comprehensive Case Study Dataset of Urban Garden Soils. Front. Environ. Sci. 6, 1–5. doi:10.3389/fenvs.2018.00136
#
###Used packages#####
library(tidyverse)#various data management and plotting options
# see Wickham, H., Grolemund, G., 2016. R for data science: import, tidy, transform, visualize, and model data. “ O’Reilly Media, Inc.”
library(data.table)
library(Hmisc)#Concise Statistical Descriptions
library(car)#scatteroplotMatrix
library(lme4) # LMEM
library(rstanarm)# WAIC calculation within R stan
library(piecewiseSEM)# obtaining R2 for LMEM and run path model
library(arm)# Bayesian models in R, see Korner-Nievergelt et al. (2015)
library(FD) #calculate functional biodiversity indices, see Laliberté and Legendre (2010)
library(rotl)#An Interface to the Open Tree of Life, see Michonneau et al. (2016)
library(ape)# for computing branche lengths, see Paradis et al. (2004) and Paradis (2011)
library(picante)#phylogenetic distance calculation, see Kembel et al. (2010)
library(geozoo);library(flexmix);library(geometry) #needed for TED and TOP from Fontana et al. 2016
library(faraway)#Variance inflation factor VIF, vif {faraway} # Borcard et al. 2011 Numerical ecology with R S. 175, VIFs > 10 should be avoided
library(corrplot)# corrplot: Wei, T. and Simko, V. (2017). R package ”corrplot”: Visualization of a Correlation Matrix
library(vegan)# NMDS ordination with metaMDS() see introduction : http://cc.oulu.fi/~jarioksa/opetus/metodi/vegantutor.pdf
library(ggvegan)#plotting ordinations with ggplot2


#decomposition means by group############
mydata<-read.csv("mydata.csv", header = TRUE, sep=";",dec = ".")

mean_func<-function(x) mean(x, na.rm=T)
se_func <- function(x) sd(x, na.rm=T)/sqrt(length(x))

# overall means
#4mm
mydata %>% #filter
  dplyr::select(Leaf_4mm, Stem_4mm) %>% #group
  summarise_at(.vars = vars(Leaf_4mm,Stem_4mm),
               .funs = c(mean="mean_func", se="se_func", n="n_distinct"))
#1mm
mydata %>% #filter
  dplyr::select(Leaf_1mm, Stem_1mm) %>% #group
  summarise_at(.vars = vars(Leaf_1mm,Stem_1mm),
               .funs = c(mean="mean_func", se="se_func", n="n_distinct"))

# means per garden habitat
mydata %>% #filter
  dplyr::select(Leaf_4mm, Stem_4mm,habitat) %>% #group
  group_by(habitat)%>% #mean etc.
  summarise_at(.vars = vars(Leaf_4mm,Stem_4mm),
               .funs = c(mean="mean_func", se="se_func", n="n_distinct"))

# means per UHI class
mydata$UHI_class<-as.character(mydata$overwarming)
mydata$UHI_class<-plyr::revalue(mydata$UHI_class, c("0"="rural", "1"="rural", "2"="suburban","3"="suburban", "4"="urban", "5"="urban" ))#rename 

mydata %>% #filter
  dplyr::select(Leaf_4mm, Stem_4mm,UHI_class) %>% #group
  group_by(UHI_class)%>% #mean etc.
  summarise_at(.vars = vars(Leaf_4mm,Stem_4mm),
               .funs = c(mean="mean_func", se="se_func", n="n_distinct"))

# Litter traits assessment ########
leaf_traits<-read.csv("leaf_traits.csv", header = TRUE, sep=";",dec = ".")

# check for normality for t.test
testvariables<-leaf_traits[ c("N","C", "C.N", "pH", "Labile_A","Labile_B","Labile_C", "Stable_D", "Stable_E", "Stable_F", "Stable_G","Stable_H", "toughness")]
#histogramms
lapply(testvariables, function(x) hist(x))
describe(testvariables)
scatterplotMatrix(testvariables)

#Shapiro-Wilk Normality Test
shapiro<-lapply(testvariables, function(x)
  shapiro.test(x)$p.value)
(shapiro <- data.frame(shapiro))
shapiro > 0.05# which variables are not normal distributed? Labile_B, C, D, E are not normal

#Wilcoxon Rank Sum and Signed Rank Tests -> robust "t-test version"
pvalue<-lapply(testvariables, function(x)
  wilcox.test(x ~ type, data=leaf_traits, na.rm=na.exclude)$p.value)
pvalue <- data.frame(pvalue)
pvalue < 0.05#
colnames(pvalue)<-paste0(colnames(pvalue), "_p")
pvalue

#means and se by group
mean_func<-function(x) mean(x, na.rm=T)
se_func <- function(x) sd(x, na.rm=T)/sqrt(length(x))
means<-leaf_traits[2:ncol(leaf_traits)] %>%
  group_by(type) %>%
  summarise_all(funs(mean=mean_func))
se<-leaf_traits[2:ncol(leaf_traits)] %>%
  group_by(type) %>%
  summarise_all(funs(se=se_func))
means<-as.data.frame(means)
se<-as.data.frame(se)



#Trait diversity indices#########
#load species by sites matrix
species_matrix<-read.csv("species_matrix.csv", header = TRUE, sep=";",dec = ".")
#load traits by species matrix
traits_mat<-read.csv("traits_mat.csv", header = TRUE, sep=";",dec = ".")
traits_mat$vertical<-plyr::revalue(traits_mat$vertical, c("surface"=1, "mixed"=2, "soil"=3))#rename
traits_mat$vertical<-as.numeric(as.character(traits_mat$vertical))

#only abundance of the species by sites is needed for the calculations with FD
(abund_sites<-species_matrix[3:ncol(species_matrix)])
abund_sites <- abund_sites[, order(colnames(abund_sites))]#order alphabetically after collnames (species)
#what is different, should be = 0
setdiff(colnames(abund_sites),rownames(traits_mat))
#what is in both
intersect(colnames(abund_sites),rownames(traits_mat))

#calculate FD indices, traits standardised = T, FEve weighted by abun = T
(funct_div<-dbFD(traits_mat, abund_sites,calc.FDiv=T, stand.x = T, w.abun = T))


# Function to compute  TED and TOP indices see Fontana et al. 2016
# input:
# - data frame 'traits': every row represents an individual, every column a trait
# - NA are not allowed
# - ADVICE: it is generally meaningful to standardise trait values (mean=0 and sd=1)

# Function to compute trait richness index TOP (Fontana et al. 2016)
# Partially adapted from Villéger et al. 2008
# It requires R libraries 'geozoo', 'flexmix' and 'geometry'                                                              #
# input:
# - data frame 'traits': every row represents an individual, every column a trait
# - number of individuals must be higher than number of traits
# - NA are not allowed
# - ADVICE: it is generally meaningful to standardise trait values (mean=0 and sd=1)
# comparison between sample and an assemblage of equidistant points (with the same number of individuals)

# List of possible REFERENCES
# Define maximum number of points (max1) and number of traits under consideration (dim1)
# Alternatively, it is possible to manually define max1 and dim1!!
max1 <- 50
dim1 <- 2

ref.matrix<-matrix(ncol=2,nrow=max1)
if (dim1 == 1) {
  i=0.9 } else { i=1.9 }
n <- 0
rows1<-0

while(rows1<max1){
  i=i+0.1
  n=n+1
  traits.ref <- sphere.solid.grid(p=dim1, n=i)
  rows1<-nrow(traits.ref$points)
  ref.matrix[n,1]<-i
  ref.matrix[n,2]<-rows1

}

k <- i+1
while(i<k){
  i=i+0.1
  n=n+1
  traits.ref <- sphere.solid.grid(p=dim1, n=i)
  rows1<-nrow(traits.ref$points)
  ref.matrix[n,1]<-i
  ref.matrix[n,2]<-rows1
}

ref.matrix<-na.omit(ref.matrix)
ref.matrix

##  TED index calculation from Fontana et al. 2016   ################################
TED.index <- function(traitdat){

  # Find the best REFERENCE (minimum number of individuals >= individuals in the sample)

  n.sample<-nrow(traitdat)

  diff1<-matrix(ncol=2,nrow=length(ref.matrix)/2)
  diff1[,1] <- ref.matrix[,1]
  diff1[,2] <- ref.matrix[,2]-n.sample
  min.diff1<-min(diff1[,2][diff1[,2]>=0])
  select.i<-diff1[diff1[,2]==min.diff1,][1]
  traits.ref <- sphere.solid.grid(p=dim1, n=select.i)

  # Transform REFERENCE in data frame
  traits.ref <- as.vector(traits.ref$points)
  ind<-length(traits.ref)/dim1
  reference<-matrix(ncol=dim1,nrow=ind)
  for (j in 1:dim1){
    reference[,j] <- traits.ref[((j-1)*ind+1):(j*ind)]
  }
  traits.ref <- as.data.frame(reference)

  # Ev. delete individuals in order to have the same number as in the sample
  x <- nrow(traits.ref)-nrow(traitdat)

  if (x!=0){

    # coordinates of the center of gravity of the vertices (Gv)
    baryv<-apply(traits.ref,2,mean)

    # euclidian dstances to Gv (dB)
    distbaryv<-rep(0,nrow(traits.ref))
    for (j in 1:nrow(traits.ref))
      distbaryv[j]<-( sum((traits.ref[j,]-baryv)^2) )^0.5

    merge1<-data.frame(traits.ref,distbaryv)

    #sort by distbaryv (descending)
    sort1 <- merge1[order(-distbaryv),]
    traits.ref<-sort1[-1:-x,-(ncol(sort1))]

  }

  # Compare with sample
  Distance.method <- "euclidean"
  D1 <- dist(traitdat, method=Distance.method)
  density.D <- density(D1)$y
  rm(D1)
  D.ref <- dist(traits.ref, method=Distance.method)
  density.D.ref <- density(D.ref)$y
  rm(D.ref)

  results <- KLdiv(cbind(density.D, density.D.ref))

  value <- results[1,2]

  TED <- 1-log10(value+1)
  TED

}

#TOP.index from Fontana et al. 2016


TOP.index <- function(traitdat){
  # TOP
  dim1 <- ncol(traitdat)
  #definitions: index i, area as empty vector
  i=0
  area<-matrix(ncol=2,nrow=nrow(traitdat))

  while(nrow(traitdat)>dim1){
    i=i+1
    # use of convhulln function
    # area
    area[i,2] <- convhulln(traitdat, c("FA","QJ"))$area

    # identity of vertices
    vert0<-convhulln(traitdat, c("Fx TO 'vert.txt'","QJ"))
    vert1<-scan("vert.txt",quiet=T)
    vert2<-vert1+1

    vertices <- vert2[-1]

    traitdat <- traitdat[-vertices,]

    area[i,1] <- length(vertices)
  }
  area<-na.omit(area)
  colSums(area)# Output (2 numbers): Number of points touched by areas; Sum of the areas (TOP index)
}

# calculate TED index
traits_scaled <- as.data.frame(scale(traits_mat))
traits_scaled$species<-rownames(traits_scaled)

TED.TOP <- matrix(nrow=3, ncol=length(unique(rownames(species_matrix))))

for (k in 1:length(unique(rownames(species_matrix)))) {
  dat.subset <- t(species_matrix[unique(rownames(species_matrix))[k],-c(1,2)])
  dat.subset2 <- subset(dat.subset, dat.subset[,1]!=0)
  list.species <- rownames(dat.subset2)
  trait.site <-subset(traits_scaled,species %in% list.species)
  TED.TOP[1,k] <- TED.index(trait.site[,1:2])
  TED.TOP[2:3,k] <- TOP.index(trait.site[,1:2])
}
colnames(TED.TOP)  <- rownames(species_matrix)
TED.TOP<-as.data.frame(t(TED.TOP))
colnames(TED.TOP)<-c("TED", "npoints", "TOP")
TED.TOP





#Phylogenetic Diversity ##########
# see Helmus et al., 2007 and Paradis 2011
#load species names, they should be checked individually before with the name list of the open tree of life project
species<-read.csv("species.csv", header = TRUE, sep=";",dec = ".")
species$species<-as.character(species$species)

taxa <- tnrs_match_names(unique(species$species), context="Animals")#Match names to the Open Tree Taxonomy
(taxa)
#create a named vector that maps the names we have for each species to the names Open Tree uses for them
taxon_map <- structure(taxa$search_string, names=taxa$unique_name)

tr <- tol_induced_subtree(taxa$ott_id)
plot(tr, show.tip.label=T)
#make own labels
tr$tip.label
tr$tip.label<-substr(tr$tip.label,1,nchar(tr$tip.label)-7)
tr$tip.label<-gsub('_ot', '', tr$tip.label)
tr$tip.label<-gsub('_ott', '', tr$tip.label)
tr$tip.label<-gsub('_o', '', tr$tip.label)
tr$tip.label<-gsub('_', ' ', tr$tip.label)

tr$node.label
tr$node.label<-substr(tr$node.label,1,nchar(tr$node.label)-7)
tr$node.label<-gsub(' ot', '', tr$node.label)
tr$node.label<-gsub(' ott', '', tr$node.label)
tr$node.label<-gsub(' o', '', tr$node.label)


plot(tr, show.tip.label=T, show.node.label = T)
## branch lengths: compute.brlen from ape has been used
tr<-compute.brlen(tr)

#phylogenetic distance calculation with picante
species_matrix_new<-read.csv("species_matrix_new.csv", header = TRUE, sep=";",dec = ".")

phy <- tr
comm <- species_matrix_new
#Phylogenetic diversity
pd.result <- pd(comm, phy, include.root=F)#include.root=F: root of your tree to correspond to the most recent ancestor of the taxa actually present in your sample
pd.result

#Phylogenetic Sp Variability (PSV): expected variance among species in a community phylogeny for a trait evolving under Brownian motion
psv.result<-psv(comm, phy)
# Phylogenetic Sp Evenness (PSE): abundance weighted
pse.result<-pse(comm, phy)
# Phylogenetic Sp Richness (PSR): = mpd times sp richness in the community.
psr.result<-psr(comm, phy)
# Phylogenetic species clustering (PSC) is a metric of the branch tip clustering of species across a sample's phylogeny
psc.result<-psc(comm, phy)


#LMEM Model comparison#####
#data preparation: exclude sites with NA values for linear mixed effect models
#N decreased from 170 to N=154 observations
mydata<-read.csv("mydata.csv", header = TRUE, sep=";",dec = ".")

var<-mydata[c("S", "E_Shannon", "TOP", "TED", "FDis", "PSV", "PSE", "PSR", "PD")]
colnames(var)<-c( "species richness", "evenness", "TOP", "TED", "FDis", "PSV", "PSE", "PSR", "PD")

#corrplot
res2 <- rcorr(as.matrix(var),type="pearson")
corrplot(res2$r, type="upper", order="hclust", p.mat = res2$P, sig.level = 0.05, insig = "blank",tl.col="black", tl.srt=45) #Text label color and rotation)

#VIF
sort(vif(var))


#z-transformation of all response variables
mydata<-mydata %>% mutate_at(c("D_Shannon", "E_Shannon", "D_Simpson", "E_Simpson","TOP",  "TED",  "PSV", "PSE", "FDis", "SR_tot", "Abun_tot", "PD", "MSIR_rate","overwarming"
                               ), funs(z= scale))

#select response variables
response<-mydata$Leaf_4mm
response<-mydata$Leaf_1mm
response<-mydata$Stem_4mm
response<-mydata$Stem_1mm

#Basic model
model_1<-lmer(log(100-response+1) ~ SR_tot_z+ Abun_tot_z + PSV_z + TED_z + (1|Garden_ID), data = mydata,REML=F)
summary(model_1)
#Model including habitat types and garden types due to sampling design
model_2<-lmer(log(100-response+1) ~ SR_tot_z+ Abun_tot_z + PSV_z + TED_z + habitat + garden_type + (1|Garden_ID), data = mydata,REML=F)
summary(model_2)
#Model including microbial activity measured as multisubstrate induced respiration with the MicroResp system
model_3<-lmer(log(100-response+1) ~ MSIR_rate_z + SR_tot_z+ Abun_tot_z + PSV_z + TED_z + habitat + garden_type + (1|Garden_ID), data = mydata,REML=F)
summary(model_3)
#Model including urbanization gradient measured as overwarming temperature from local climate model by Parlow et al. 2011
model_4<-lmer(log(100-response+1) ~ MSIR_rate_z + SR_tot_z+ Abun_tot_z + PSV_z + TED_z + overwarming_z + habitat + garden_type + (1|Garden_ID), data = mydata,REML=F)
summary(model_4)

#R2 calculation according to Nakagawa, Shinichi, and Holger Schielzeth. "A general and simple method for obtaining R2 from generalized linear mixed-effects models." Methods in Ecology and Evolution 4.2 (2013): 133-142
(model_fits<-sem.model.fits(model_1))#R2 calculation
(model_fits<-sem.model.fits(model_2))#R2 calculation
(model_fits<-sem.model.fits(model_3))#R2 calculation
(model_fits<-sem.model.fits(model_4))#R2 calculation


model_1_stan<-stan_lmer(log(100-response+1) ~ SR_tot_z+ Abun_tot_z + PSV_z + var_body_size_z + (1|Garden_ID),
                        data = mydata,REML=F)#convert int stan object
(waic_values<-waic(model_1_stan))#computation of WAIC with the converted lmer_stan object based on the loo package, see: loo.stanreg {rstanarm}

model_2_stan<-stan_lmer(log(100-response+1) ~ SR_tot_z+ Abun_tot_z + PSV_z + var_body_size_z + habitat + garden_type + (1|Garden_ID),
                        data = mydata,REML=F)#convert int stan object
(waic_values<-waic(model_2_stan))#computation of WAIC with the converted lmer_stan object based on the loo package, see: loo.stanreg {rstanarm}

model_3_stan<-stan_lmer(log(100-response+1) ~ MSIR_rate_z + SR_tot_z+ Abun_tot_z + PSV_z + var_body_size_z + habitat + garden_type + (1|Garden_ID),
                        data = mydata,REML=F)#convert int stan object
(waic_values<-waic(model_3_stan))#computation of WAIC with the converted lmer_stan object based on the loo package, see: loo.stanreg {rstanarm}

model_4_stan<-stan_lmer(log(100-response+1) ~ MSIR_rate_z + SR_tot_z+ Abun_tot_z + PSV_z + var_body_size_z + overwarming_z + habitat + garden_type + (1|Garden_ID),
                        data = mydata,REML=F)#convert int stan object
(waic_values<-waic(model_4_stan))#computation of WAIC with the converted lmer_stan object based on the loo package, see: loo.stanreg {rstanarm}

#Final Model: Frequentist approach######
mod_final<-lmer(log(100-response+1) ~ MSIR_rate_z + SR_tot_z + Abun_tot_z + PSV_z + FEve_z + overwarming_z + habitat + garden_type + (1|Garden_ID),
            data = mydata, REML=F)
summary(mod_final)

#Assessing model fits -> iid#####
mod<-mod_final
par(mfrow=c(2,2), mar=c(4,4,2,1), mgp=c(2.2,0.8,0))

scatter.smooth(fitted(mod), resid(mod)); abline(h=0, lty=2)
mtext("Tukey-Anscombe Plot", 3, line=0.8, cex=0.8)  # residuals vs. fitted

qqnorm(resid(mod), main="Normal qq-plot, residuals", cex.main=0.8) # qq of residuals
qqline(resid(mod))

scatter.smooth(fitted(mod), sqrt(abs(resid(mod)))) # res. var vs. fitted

qqnorm(ranef(mod)$Garden_ID[,1], main="Normal qq-plot, random effects", cex.main=0.8)
qqline(ranef(mod)$Garden_ID[,1]) # qq of random effects

# Drawing conclusions with Posterior Distribution######
set.seed(0470)    # specify the seed (starting value for your random generator)
nsim <- 10000
#making a df with all Post. distr. with the sim(bsim)

#only 4 mm mesh bags
testvariables<-mydata[, c("Leaf_4mm", "Stem_4mm")]
#only 1 mm mesh bags -> different data set required because of the exclusion of Macrofauna
testvariables<-mydata[, c("Leaf_1mm", "Stem_1mm")]

lapply(testvariables, function(x)
  sim(lmer(log(100-x+1)~
             MSIR_rate_z + SR_tot_z + Abun_tot_z + PSV_z + var_body_size_z + overwarming_z + habitat + garden_type + (1|Garden_ID)
           , data = mydata, REML=F),n.sim=nsim))

#95 % credible intervals and means of the fitted posterior distributions can be calculated based on the values from the sim
# see Book of Körner-Nievergelt et al. 2015: Bayesian data analysis in ecology using linear models with R, BUGS, and Stan




########## NMDS ordination MIRS peak area integration#############
#load mid-DRIFTS peaks
mydata<-read.csv("PEAKS.csv", header = TRUE, sep=";",dec = ".")
measurements<-mydata[,2:9]

#rankindex -> use gower as distance matrix, since a good dissimilarity index for multidimensional scaling should have a high rank-order similarity with gradient separation.
sort(rankindex(mydata$habitat,measurements, c("euc", "man", "gow","bray", "jac", "kul")))
(ord<-metaMDS(measurements,distance = "gow",k=2,trymax=1000))

stressplot(ord)#Shepard plot, which shows scatter around the regression between the interpoint distances in the final configuration (i.e., the distances between each pair of communities) against their original dissimilarities. Large scatter around the line suggests that original dissimilarities are not well preserved in the reduced number of dimensions

# Shepard plot and goodness of fit
par(mfrow=c(1,2))
stressplot(ord, main="Shepard plot")
gof <- goodness(ord)
plot(ord, type="t", main="Goodness of fit") #Poorly fitted sites have larger bubbles.
points(ord, display="sites", cex=gof*300)
ord$stress #High stress values indicate that there was no 2-dimensional arrangement of your points that reflect their similarities. A rule of thumb is that stress values should ideally be less than 0.2 or even 0.1.
ordiplot(ord)

autoplot(ord)

###### Path model #####

mydata<-read.csv("mydata_SEM.csv", header = TRUE, sep=";",dec = ".")
# including microbial data: qPCR measurements of bacterial (16S) and fungal (18S) gene copy numbers, see Tresch, S., Moretti, M., Le Bayon, R.-C., Mäder, P., Zanetta, A., Frey, D., Stehle, B., Kuhn, A., Munyangabe, A., Fliessbach, A., 2018b. Urban Soil Quality Assessment—A Comprehensive Case Study Dataset of Urban Garden Soils. Front. Environ. Sci. 6, 1–5. doi:10.3389/fenvs.2018.00136
microbes<-read.csv("qPCR_2018.csv", header = TRUE, sep=";",dec = ".")
microbes$Number<-paste0(microbes$Disturbance,"_",microbes$Garden_ID )
# microbes<-microbes[,c("Number", "X16S", "X18S")]
microbes<-microbes %>%
  dplyr::select("Plot_ID", "X16S"="X16S_cor","X18S"="X18S_cor" )#new with APA9 corrected value:18.09.18
hist(microbes$X16S)
hist(microbes$X18S)
mydata<-merge(mydata,microbes,by=c("Plot_ID"))
mydata<-mydata%>% 
  dplyr::rename(Bacteria=X16S,Fungi=X18S)

mydata<-mydata[complete.cases(mydata[]),] #Remouve NA's -> N =143 if every missing row is remouved

#z-transformation of all response variables
mydata<-mydata %>% mutate_at(c("D_Shannon", "E_Shannon", "D_Simpson", "E_Simpson","TOP",  "TED",  "PSV", "PSE", "cv_body_size", "FEve", "var_body_size", "SR_tot", "Abun_tot", "FDis", "PD", "MSIR_rate","overwarming", "sun_exposure", "bareground", "Garden_intensity","management_transf","garden_age","pesticides_freq",
                               "slope", "years_managed", "weeding_freq", "leaves_freq", "fert_freq", "disturbance_freq", "plant_SR",
                               "pH", "Clay", "TOC.clay", "Bacteria", "C.N", "SA", "TOC", "TON", "DOC", "DON",  "WHC", "EC", "BD", "BasalResp", "Depth", "Cmic", "Nmic", "SumCO2", "SumNmin", "pen_0_20", "Cmic.Corg",
                               "Pb", "Sb", "As", "Ba", "Zn"
), funs(z= scale))

response<-mydata$Leaf_4mm

#for SEM path-model variable selection see Materials and Methods as well as:
# 1) Shipley, B., 2016. Cause and correlation in biology: a user’s guide to path analysis, structural equations and causal inference with R. Cambridge University Press.
# 2) Lefcheck, J.S., 2016. piecewiseSEM: Piecewise structural equation modelling in r for ecology, evolution, and systematics. Methods Ecol. Evol. 7, 573–579. doi:10.1111/2041-210X.12512

# example of model selection:
# FIRST START WITH YOUR A PRIORI SEM, INCLUDING ALL HYPOTHESIS YOU WANT TO TEST!!!
# SECONDLY AND ONLY TO A MINOR EXTEND: one can check the goodness-of-fit test to add or remove some variables, 
# but only if this make sense to your hypothesis and also if it make sense in a biological way!

#L4  AICc: 309.249,F.C. 102.26, p 0.878
# without MSIR + TED, AICc decreased, p increased --> remove MSIR + TED
#L4  AICc: 304.243,F.C. 102.91, p 0.894
# without habitat + E_Shannon, AICc decreased, p increased --> remove habitat + E_Shannon
#L4  AICc: 294.931,F.C. 104.54, p 0.897
# with weeding_freq + E_Shannon model worse 
# with fert_freq + PSV, AICc increased, p decreased --> keep fert_freq + PSV
#L4  AICc: 303.502,F.C. 107.7, p 0.954
# without PSV + TED, AICc decreased, p decreased --> remove PSV + TED
# without WHC + TED, AICc decreased, p decreased --> remove WHC + TED
# without habitat + PSV, AICc decreased, p decreased --> remove habitat + PSV
# without management_transf_z + S, AICc decreased, p decreased --> remove management_transf_z + S
# with pesticides_freq - S

#best model 
#L4  AICc: 299.69,F.C. 124.19, p 0.963

mod27.sem<-list(
  decomposition = lme(log(100-response+1)~ MSIR_rate_z + SR_tot_z + E_Shannon_z + PSV_z + TED_z + habitat + garden_type + overwarming_z  , random = ~1 | Garden_ID, data = mydata),
  #Predicting MSIR
  MSIR = lme(MSIR_rate_z ~ Bacteria_z + BD_z + WHC_z + Cmic_z + management_transf_z  + sun_exposure_z + plant_SR_z + bareground_z , random = ~1 | Garden_ID, data = mydata),
  #Predicting S
  S = lme(SR_tot_z ~ SumNmin_z + Sb_z + leaves_freq_z + bareground_z + MSIR_rate_z + plant_SR_z, random = ~1 | Garden_ID, data = mydata),
  #Predicting E_Shannon
  E_Shannon = lme(E_Shannon_z ~ PSV_z + SR_tot_z + TED_z +  management_transf_z +  MSIR_rate_z + overwarming_z , random = ~1 | Garden_ID, data = mydata),
  #Predicting PSV
  PSV = lme(PSV_z ~ overwarming_z + fert_freq_z  , random = ~1 | Garden_ID, data = mydata),
  #Predicting TED
  TED = lme(TED_z ~ overwarming_z + habitat + SR_tot_z + TON_z , random = ~1 | Garden_ID, data = mydata)
)

#SEM output
sem.fit(mod27.sem,mydata,conditional = T)#Run goodness-of-fit tests
(sem.coef<-sem.coefs(modelList = mod27.sem,data=mydata))#Evaluate path significance using unstandardized coefficients
(sem.fit<-sem.model.fits(modelList = mod27.sem))#Explore individual model fits
sem.plot(mod27.sem, mydata,show.nonsig = F, alpha = 0.05)#The arrow width indicates the strength of the effect (based on estimates from sem.coefs). Dashed and grey arrows indicate non-significant effects. Red arrows indicate negative effects.

